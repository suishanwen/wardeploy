

/****** Object:  Table [dept_income_apport]    Script Date: 2019/11/26 9:56:46 ******/
IF EXISTS(SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dept_income_apport]')and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	DROP TABLE [dept_income_apport]

GO

/****** Object:  Table [dept_income_apport]    Script Date: 2019/11/26 9:56:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dept_income_apport](
	[income_apport_id] [int] IDENTITY(1,1) NOT NULL,
	[acct_year] [nvarchar](4) NOT NULL,
	[acct_month] [nvarchar](2) NOT NULL,
	[comp_code] [nvarchar](20) NOT NULL,
	[dept_id] [int] NOT NULL,
	[charge_detail_id] [int] NOT NULL,
	[income_amount] [numeric](18, 2) NOT NULL,
 CONSTRAINT [PK__dept_inc__E2C97C2155B27826] PRIMARY KEY CLUSTERED 
(
	[income_apport_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport', @level2type=N'COLUMN',@level2name=N'income_apport_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'年度' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport', @level2type=N'COLUMN',@level2name=N'acct_year'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'月份' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport', @level2type=N'COLUMN',@level2name=N'acct_month'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'单位编码' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport', @level2type=N'COLUMN',@level2name=N'comp_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'科室id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport', @level2type=N'COLUMN',@level2name=N'dept_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'收费项目id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport', @level2type=N'COLUMN',@level2name=N'charge_detail_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'金额' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport', @level2type=N'COLUMN',@level2name=N'income_amount'
GO



/****** Object:  Table [dept_income_apport_rule]    Script Date: 2019/11/26 9:56:56 ******/
IF EXISTS(SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dept_income_apport_rule]')and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dept_income_apport_rule]
GO

/****** Object:  Table [dept_income_apport_rule]    Script Date: 2019/11/26 9:56:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dept_income_apport_rule](
	[income_rule_id] [int] IDENTITY(1,1) NOT NULL,
	[acct_year] [nvarchar](4) NOT NULL,
	[acct_month] [nvarchar](2) NOT NULL,
	[comp_code] [nvarchar](20) NOT NULL,
	[charge_kind_id] [int] NULL,
	[charge_detail_id] [int] NULL,
	[dept_ordered_id] [int] NOT NULL,
	[dept_perform_id] [int] NOT NULL,
	[dept_ordered_percent] [numeric](18, 4) NOT NULL,
	[dept_perform_percent] [numeric](18, 4) NOT NULL,
	[rule_flag] [char](1) NOT NULL,
 CONSTRAINT [PK__dept_inc__C2D2A5CBF68FD87A] PRIMARY KEY CLUSTERED 
(
	[income_rule_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport_rule', @level2type=N'COLUMN',@level2name=N'income_rule_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'年度' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport_rule', @level2type=N'COLUMN',@level2name=N'acct_year'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'月份' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport_rule', @level2type=N'COLUMN',@level2name=N'acct_month'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'单位编码' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport_rule', @level2type=N'COLUMN',@level2name=N'comp_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'收费类别' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport_rule', @level2type=N'COLUMN',@level2name=N'charge_kind_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'收费项目' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport_rule', @level2type=N'COLUMN',@level2name=N'charge_detail_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'开单科室id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport_rule', @level2type=N'COLUMN',@level2name=N'dept_ordered_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'执行科室id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport_rule', @level2type=N'COLUMN',@level2name=N'dept_perform_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'开单科室比例' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport_rule', @level2type=N'COLUMN',@level2name=N'dept_ordered_percent'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'执行科室比例(自动计算)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport_rule', @level2type=N'COLUMN',@level2name=N'dept_perform_percent'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'规则标识 1 、收费类别 2、收费项目' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_income_apport_rule', @level2type=N'COLUMN',@level2name=N'rule_flag'
GO


/****** Object:  Table [dept_performance_cost]    Script Date: 2019/11/26 9:58:44 ******/
IF EXISTS(SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dept_performance_cost]')and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dept_performance_cost]
GO

/****** Object:  Table [dept_performance_cost]    Script Date: 2019/11/26 9:58:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dept_performance_cost](
	[performance_cost_id] [int] IDENTITY(1,1) NOT NULL,
	[acct_year] [nvarchar](4) NOT NULL,
	[acct_month] [nvarchar](2) NOT NULL,
	[comp_code] [nvarchar](20) NOT NULL,
	[dept_id] [int] NOT NULL,
	[cost_subj_id] [int] NULL,
	[cost_amount] [numeric](18, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[performance_cost_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost', @level2type=N'COLUMN',@level2name=N'performance_cost_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'年度' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost', @level2type=N'COLUMN',@level2name=N'acct_year'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'月份' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost', @level2type=N'COLUMN',@level2name=N'acct_month'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'单位编码' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost', @level2type=N'COLUMN',@level2name=N'comp_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'科室ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost', @level2type=N'COLUMN',@level2name=N'dept_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'金额' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost', @level2type=N'COLUMN',@level2name=N'cost_amount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'成本项目id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost', @level2type=N'COLUMN',@level2name=N'cost_subj_id'
GO


/****** Object:  Table [dept_performance_cost_rule]    Script Date: 2019/11/26 9:58:54 ******/
IF EXISTS(SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dept_performance_cost_rule]')and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dept_performance_cost_rule]
GO

/****** Object:  Table [dept_performance_cost_rule]    Script Date: 2019/11/26 9:58:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dept_performance_cost_rule](
	[performance_cost_rule_id] [int] IDENTITY(1,1) NOT NULL,
	[acct_year] [nvarchar](4) NULL,
	[acct_month] [nvarchar](2) NULL,
	[comp_code] [nvarchar](20) NULL,
	[dept_id] [int] NULL,
	[fun_code] [nvarchar](200) NULL,
	[fun_paras] [nvarchar](500) NULL,
	[fun_paras_values] [nvarchar](4000) NULL,
PRIMARY KEY CLUSTERED 
(
	[performance_cost_rule_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost_rule', @level2type=N'COLUMN',@level2name=N'performance_cost_rule_id'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'年度' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost_rule', @level2type=N'COLUMN',@level2name=N'acct_year'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'月份' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost_rule', @level2type=N'COLUMN',@level2name=N'acct_month'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'单位编码' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost_rule', @level2type=N'COLUMN',@level2name=N'comp_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'函数' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost_rule', @level2type=N'COLUMN',@level2name=N'fun_code'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'函数参数' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost_rule', @level2type=N'COLUMN',@level2name=N'fun_paras'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'函数参数值' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost_rule', @level2type=N'COLUMN',@level2name=N'fun_paras_values'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'科室id' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'dept_performance_cost_rule', @level2type=N'COLUMN',@level2name=N'dept_id'
GO


/******  INSERT  sys_target_base_para******/
delete from sys_target_base_para where para_code = 'oes_dept_cost_part';
INSERT INTO sys_target_base_para ([para_code], [table_sql])
VALUES
	(
		N'oes_dept_cost_part',
		N'select case code_value when ''02'' then 2 when ''04'' then 4 when ''05'' then 5 when ''06'' then 6 when ''07'' then ''07'' end as para_id,code_value para_value,code_name para_name from UP_CODELIST where codetype=''dept_part''  and code_value in (''02'',''04'',''05'',''06'',''07'') order by code_value asc'
	);

delete from sys_target_base_para where para_code = 'oes_dept_cost_attr';
INSERT INTO sys_target_base_para ([para_code], [table_sql])
VALUES
	(
		N'oes_dept_cost_attr',
		N'select 1 para_id,''07'' para_value,''医疗成本'' para_name union select 2 para_id,''01,02,03,07'' para_value,''医疗全成本'' para_name union select 3 para_id,''01,02,03,04,05,06,07'' para_value,''医院全成本'' para_name'
	);
	
	
/******  INSERT  sys_target_base_define******/
delete from sys_target_base_define where fun_type = '03' and fun_code ='DEPT_COST_CBKH';
INSERT INTO sys_target_base_define (
	[fun_type],
	[fun_code],
	[fun_note],
	[come_from],
	[fun_para],
	[fun_formular],
	[mod_code]
)
VALUES
	(
		N'03',
		N'DEPT_COST_CBKH',
		N'科室成本_成本考核',
		'0',
		N'oes_dept_cost_part|oes_dept_cost_attr|oes_dept_source_way',
		NULL,
		N'12'
	);



